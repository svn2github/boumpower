#include <windows.h>
#define IDC_STATIC -1
#define IDE_EDIT1 201

